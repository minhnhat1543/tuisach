import React from 'react';
import Layout from './shared/layout';

const NotFound = () => {
  const style = {
    fontWeight: 'bold',
    textAlign: 'center',
  }

  return (
    <Layout>
      <p style={style}>Thật không may, chúng tôi không thể tìm thấy trang đó</p>
    </Layout>
  );
}

export default NotFound;