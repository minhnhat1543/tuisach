import React, { useContext, useEffect } from 'react';
import { withRouter } from 'react-router-dom';
import Layout from '../../shared/layout';
import { CartContext } from '../../../context/cart-context';

const Success = ({ history }) => {
  const { clearCart, cartItems } = useContext(CartContext);
  useEffect(() => {
    if (cartItems.length !==0) { clearCart() }
  }, [clearCart, cartItems]);

  return (
    <Layout>
      <div className='checkout'>
        <h1>Cảm ơn bạn đã đặt hàng </h1>
        <p>Chúng tôi hiện đang xử lý đơn đặt hàng của bạn và
          sẽ gửi cho bạn một email xác nhận trong thời gian ngắn
        </p>
        <div>
          <button className='button is-black nomad-btn submit' 
          onClick={() => history.push('/shop')}>
          Tiếp tục mua sắm
          </button>
        </div>
      </div>
    </Layout>
  );
}

export default withRouter(Success);