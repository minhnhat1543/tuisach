import React from 'react';
import { withRouter } from 'react-router-dom';
import studioBag from '../../assets/studio-bag.png';
import './main-section.styles.scss';

const MainSection = ({ history }) => {
  return (
    <div className='main-section-container'>
      <div className='main-section-middle'>
        <div className='ms-m-image'>
          <img src={studioBag} alt='studio bag'/>
        </div>
        <div className='ms-m-description'>
          <h2>Được thiết kế cho thời trang. Chế tạo cho thể thao.</h2>
          <p>
          Chúng tôi tạo ra các sản phẩm có thể chuyển đổi dễ dàng từ ngày sang đêm.
            Từ phòng họp đến phòng tập thể dục và mọi nơi ở giữa,
            mỗi tác phẩm của Nomads được tạo ra một cách chu đáo để trở thành sự cân bằng hoàn hảo của
            hình thức và chức năng.
          </p>
          <button className='button is-black' id='shop-now' onClick={()=> history.push('/product/1')}>
            STUDIO BAG
          </button>
        </div>
      </div>
    </div>
  );
}

export default withRouter(MainSection);