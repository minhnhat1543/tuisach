import React from 'react';
import { withRouter } from 'react-router-dom';

const Total = ({ itemCount, total, history, clearCart }) => {
  return (
    <div className='total-container'>
      <div className='total'>
        <p>Tổng sản phẩm: {itemCount}</p>
        <p>{`Giá: $${total}`}</p>
      </div>
      <div className='checkout'>
        <button 
          className='button is-black' 
          onClick={() => history.push('/checkout')}>Thủ tục thanh toán</button>
        <button className='button is-white' onClick={() => clearCart()}>Xóa tất cả</button>  
      </div>
    </div>
  );
}

export default withRouter(Total);