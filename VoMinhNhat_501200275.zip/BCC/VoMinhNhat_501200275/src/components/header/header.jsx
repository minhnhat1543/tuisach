import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import CartIcon from '../cart-icon/cart-icon';
import { auth } from '../../firebase';
import { UserContext } from '../../context/user-context'
import './header.styles.scss';

const Header = () => {
  const { user } = useContext(UserContext);
  console.log('user', user);
  return (
    <nav className='nav-menu container'>
      <div className='logo'>
        <Link to='/'>MNSHOP</Link>
      </div>
      <ul>
        <li>
          <Link to='/'>
            Trang chủ
          </Link>
        </li>
        <li>
          <Link to='/shop'>
            Cửa hàng
          </Link>
        </li>
        {
          !user && 
          <li>
            <Link to='/sign-in'>
              Đăng nhập
            </Link>
          </li>
        }
        {
          user && 
          <li onClick={() => auth.signOut()}>
            Đăng xuất
          </li>
        } 
        {
          !user && 
          <li>
            <Link to='/sign-up'>
             Đăng Ký
            </Link>
          </li>
        }
      </ul>
      <CartIcon />Giỏ hàng
    </nav>
  );
}

export default Header;