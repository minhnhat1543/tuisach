// import firebase from 'firebase/app';
// import 'firebase/firestore'; // for the db
// import 'firebase/auth';

import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const config = {
  apiKey: "AIzaSyBw-B6lccCjA8kQgWd2I8Y8sh4DaV1GJMQ",
  authDomain: "minhnhat12-8f238.firebaseapp.com",
  projectId: "minhnhat12-8f238",
  storageBucket: "minhnhat12-8f238.appspot.com",
  messagingSenderId: "118723412326",
  appId: "1:118723412326:web:ee4ebd913b11e3304f88a7",
  measurementId: "G-REV8CVNY1H"
}

firebase.initializeApp(config);

const firestore = firebase.firestore();
const auth = firebase.auth();

const createUserProfileDocument = async (userAuth, additionalData) => {
  if (!userAuth) { return };

  const userRef = firestore.doc(`users/${userAuth.uid}`) //users/uniq26535
  const snapShot = await userRef.get();

  if (!snapShot.exists) {
    const { displayName, email } = userAuth;
    const createdAt = new Date();

    try {
      await userRef.set({
        displayName,
        email,
        createdAt,
        ...additionalData
      });
    } catch (error) {
      console.log('error creating user', error.message);
    }
  }

  return userRef;
}

export {
  firestore,
  createUserProfileDocument,
  auth,
}