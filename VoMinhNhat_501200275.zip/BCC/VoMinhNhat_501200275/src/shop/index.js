const SHOP_DATA = [
  {
    id: 1,
    title: 'Studio Bag',
    description: 'Studio Bag giống hệt với người tiền nhiệm của nó cộng với một vài inch nữa để yêu thích. Chuyển từ túi xách sang ba lô sang đeo chéo đơn giản bằng cách thay đổi dây đeo. Mang nó đi bất cứ đâu - nó sẽ sẵn sàng đáp ứng nhu cầu của bạn và bắt kịp phong cách sống của bạn.',
    imageUrl: 'https://i.ibb.co/PcXVJ8m/studiobag.jpg',
    price: 15,
  },
  {
    id: 2,
    title: 'Cumulus',
    description: 'Nhẹ như không khí. Cumulus được bọc trong nylon chống thấm giống như đám mây và có nội thất chính rộng rãi. Thu gọn nó để dễ dàng di chuyển và đóng nó lại bằng các chốt nam châm.',
    imageUrl: 'https://i.ibb.co/NtpJ0XQ/cumulus-olive.png',
    price: 28,
  },
  {
    id: 3,
    title: 'Dance Bag Nylon',
    description: 'Đối với những ngày mà bạn chỉ cần lấy và đi. Dance Bag là một chiếc ba lô nhỏ gọn, hình giọt nước được bọc trong nylon chống thấm nước. Đó là hành trang hoàn hảo cho cuộc sống năng động của bạn.',
    imageUrl: 'https://i.ibb.co/yRKyXPJ/dance-nylon.png',
    price: 35,
  },
  {
    id: 4,
    title: 'Stratus Backpack',
    description: 'Stratus được bọc trong lớp nylon chống thấm nước giống như đám mây và có các túi bên ngoài + bên trong để đựng chai nước, ô và máy tính xách tay của bạn. Với tay sang một bên để truy cập vào ngăn chính khi đang di chuyển. Thu gọn nó để đi lại dễ dàng. Ba lô của bạn vừa được nâng cấp.',
    imageUrl: 'https://i.ibb.co/Br2W7F0/stratus-backpack.png',
    price: 30,
  },
  {
    id: 5,
    title: 'Cirrus',
    description: 'Ba lô Cirrus được bọc trong nylon chống thấm nước giống như đám mây và có nhiều túi bên trong và bên ngoài, bao gồm cả túi đựng điện thoại + pin tích hợp để duy trì hoạt động khi di chuyển. Phiếu hành lý và bao đựng hộ chiếu an toàn làm cho nó trở thành người bạn đồng hành hoàn hảo. Phiêu lưu đi.',
    imageUrl: 'https://i.ibb.co/CPv6xTF/cirrus1.jpg',
    price: 65,
  },
  {
    id: 6,
    title: 'Mini Circle',
    description: '  Mini Circle là phong cách lấy và đi đa năng tối ưu. Chuyển từ đeo chéo sang thắt lưng sang vòng tay đơn giản bằng cách thay đổi dây đeo. Pin tích hợp bên trong có thể sạc thiết bị USB của bạn. thân thiện với người ăn chay.',
    imageUrl: 'https://i.ibb.co/LNNw217/mini-circle.png',
    price: 40,
  },
  {
    id: 7,
    title: 'Studio Bag Vaqueta',
    description: 'Mini Circle là phong cách lấy và đi đa năng tối ưu. Chuyển từ đeo chéo sang thắt lưng sang vòng tay đơn giản bằng cách thay đổi dây đeo. Pin tích hợp bên trong có thể sạc thiết bị USB của bạn. thân thiện với người ăn chay. ',
    imageUrl: 'https://i.ibb.co/QmGdpLf/studio-bag-vaqueta.jpg',
    price: 75,
  },
  {
    id: 8,
    title: 'Sling',
    description: 'Sling được bọc trong nylon chống thấm nước giống như đám mây, có tám túi và có thể được đeo như túi thắt lưng hoặc dây đeo chéo. Năm màu, nhiều chế độ mang, tất cả các bạn. Ăn chay thân thiện + dành cho tất cả mọi người.',
    imageUrl: 'https://i.ibb.co/LzyPnF3/sling.png',
    price: 25,
  },
];

export default SHOP_DATA;